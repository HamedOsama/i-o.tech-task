const Line = () => {
  return (
    <div className="sm:mx-3 mx-1 px-2 border-b border-zinc-300" />
  )
}

export default Line;