const env = {
  // API_URL: "http://localhost:8000/api/v1",
  // ImageUrl: "http://localhost:8000/images/",
  API_URL: "https://64103182e1212d9cc92c334f.mockapi.io/api/gym",
  ImageUrl: "https://api.kit-hardware-center.com/images/",
}
// const API_URL = "http://localhost:8000/api/v1";
// const ImageUrl = "http://localhost:8000/images/";
// const API_URL = "https://hatly-server.onrender.com/api/v1";
// const API_URL = "https://hatlyapi.trendlix.com/api/v1"
export default env;